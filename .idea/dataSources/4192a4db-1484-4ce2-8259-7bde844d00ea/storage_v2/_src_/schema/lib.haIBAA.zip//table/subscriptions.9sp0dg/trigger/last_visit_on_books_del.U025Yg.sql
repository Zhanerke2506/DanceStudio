create definer = root@localhost trigger last_visit_on_books_del
    after delete
    on subscriptions
    for each row
BEGIN
 UPDATE m2m_books_authors
 LEFT JOIN (SELECT sb_book,
 MAX(sb_start) AS last_visit
 FROM subscriptions
GROUP BY sb_book) AS prepared_data
 ON b_id = sb_book
 SET s_last_visit = last_visit
 WHERE b_id = OLD.sb_book;
 END;

