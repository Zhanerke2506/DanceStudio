create
    definer = root@localhost procedure subs_upd(IN id int)
BEGIN
	DECLARE ids int;
    DECLARE lname varchar(150);
    set ids=id;
    case 
		when(idd=1)
			then update subscribers set s_name = ("Акимжан Ж.К");
	end case;

END;

