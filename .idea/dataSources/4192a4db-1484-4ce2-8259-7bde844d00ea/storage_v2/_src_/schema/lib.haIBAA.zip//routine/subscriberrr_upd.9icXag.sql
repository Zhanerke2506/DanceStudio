create
    definer = root@localhost procedure subscriberrr_upd(IN id int, IN newname varchar(150))
BEGIN
	update subscribers set s_name = newname where id=s_id;

END;

