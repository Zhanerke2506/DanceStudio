create definer = root@localhost trigger last_visit_on_subscriptions_ins
    after insert
    on subscriptions
    for each row
BEGIN
 IF (SELECT IFNULL(s_last_visit, '1970-01-01')
 FROM subscribers
 WHERE s_id = NEW.sb_subscriber) < NEW.sb_start
 THEN
 UPDATE subscribers
 SET s_last_visit = NEW.sb_start
 WHERE s_id = NEW.sb_subscriber;
 END IF;
 END;

