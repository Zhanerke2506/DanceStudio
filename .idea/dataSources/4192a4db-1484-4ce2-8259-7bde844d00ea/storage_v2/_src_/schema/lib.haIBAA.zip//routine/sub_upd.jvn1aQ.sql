create
    definer = root@localhost procedure sub_upd(IN id int, IN nname varchar(150))
BEGIN
	DECLARE ids int;
    DECLARE lname varchar(150);
    set ids=id;
    case 
		when(idd=1)
			then set lname=" Акимжан Ж.К";
	end case;

END;

