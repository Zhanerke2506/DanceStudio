create
    definer = root@localhost function READ_DURATION_AND_STATUS(start_date date, finish_date date) returns varchar(150)
    deterministic
BEGIN
DECLARE days INT;
DECLARE message VARCHAR(150);
SET days = DATEDIFF(finish_date, start_date);
CASE
 WHEN (days<10) 
	THEN SET message = ' OK';
 WHEN ((days>=10) AND (days<=30)) 
	THEN SET message = ' NOTICE';
 WHEN (days>30) 
	THEN SET message = ' WARNING';
END CASE;
RETURN CONCAT(days, message);
END;

