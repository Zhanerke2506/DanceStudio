create definer = root@localhost trigger last_visit_on_subscriptions_upd
    after update
    on subscriptions
    for each row
BEGIN
 UPDATE subscribers
 LEFT JOIN (SELECT sb_subscriber,
 MAX(sb_start) AS last_visit
 FROM subscriptions
GROUP BY sb_subscriber) AS prepared_data
 ON s_id = sb_subscriber
 SET s_last_visit = last_visit
 WHERE s_id IN (OLD.sb_subscriber, NEW.sb_subscriber);
 END;

