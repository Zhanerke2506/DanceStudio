create definer = root@localhost trigger last_visit_on_books_ins
    after insert
    on subscriptions
    for each row
BEGIN
 IF (SELECT IFNULL(s_last_visit, '1970-01-01')
 FROM m2m_books_authors
 WHERE b_id = NEW.sb_book) < NEW.sb_start
 THEN
 UPDATE m2m_books_authors
 SET s_last_visit = NEW.sb_start
 WHERE b_id = NEW.sb_book;
 END IF;
 END;

