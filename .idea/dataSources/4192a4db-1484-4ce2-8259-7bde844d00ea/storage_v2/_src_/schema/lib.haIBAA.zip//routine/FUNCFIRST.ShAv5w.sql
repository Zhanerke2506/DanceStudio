create
    definer = root@localhost function FUNCFIRST(sub_id int) returns varchar(300) deterministic
BEGIN
DECLARE id INT;
DECLARE books VARCHAR(300);
SET id=sub_id;
SET books = (select group_concat(sb_book)
from subscriptions
where sb_subscriber=id
and sb_is_active='Y');
RETURN CONCAT('ID:',id,'   BOOKS:',books);
END;

