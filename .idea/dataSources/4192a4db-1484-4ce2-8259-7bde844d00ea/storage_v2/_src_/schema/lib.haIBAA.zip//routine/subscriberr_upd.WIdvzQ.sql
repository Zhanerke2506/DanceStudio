create
    definer = root@localhost procedure subscriberr_upd(IN id int, IN newname varchar(150))
BEGIN
	DECLARE ids int;
    DECLARE newname varchar(150);
    set ids=id;
	update subscribers set s_name = newname where ids=s_id;

END;

