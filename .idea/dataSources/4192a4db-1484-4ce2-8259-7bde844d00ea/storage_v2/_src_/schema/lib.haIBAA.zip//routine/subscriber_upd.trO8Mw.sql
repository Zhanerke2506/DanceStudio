create
    definer = root@localhost procedure subscriber_upd(IN id int, IN newname varchar(150))
BEGIN
	DECLARE ids int;
    DECLARE newname varchar(150);
    set ids=id;
	update subscribers set s_name = newname where ids=id;

END;

