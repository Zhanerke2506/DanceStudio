create
    definer = root@localhost procedure subscri_upd(IN id int, IN newname varchar(150))
BEGIN
	DECLARE ids int;
    DECLARE lname varchar(150);
    set ids=id;
    case 
		when(ids=id)
			then update subscribers set s_name = lname where ids=id;
	end case;

END;

