create
    definer = root@localhost procedure sub_updd(IN id int)
BEGIN
	DECLARE ids int;
    DECLARE lname varchar(150);
    set ids=id;
    case 
		when(idd=1)
			then set lname=" Акимжан Ж.К";
	end case;

END;

