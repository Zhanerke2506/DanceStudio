create
    definer = root@localhost procedure date_upd()
BEGIN
	update subscribers set s_last_visit = sysdate();
END;

