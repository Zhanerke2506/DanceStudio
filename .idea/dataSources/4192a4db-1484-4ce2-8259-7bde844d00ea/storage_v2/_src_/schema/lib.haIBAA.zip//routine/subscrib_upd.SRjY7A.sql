create
    definer = root@localhost procedure subscrib_upd(IN id int, IN newname varchar(150))
BEGIN
	DECLARE ids int;
    DECLARE lname varchar(150);
    set ids=id;
	update subscribers set s_name = lname where ids=id;

END;

